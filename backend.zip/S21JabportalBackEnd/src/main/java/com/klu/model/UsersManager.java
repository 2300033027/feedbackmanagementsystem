 package com.klu.model;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klu.repository.UsersRepository;



@Service
public class UsersManager {
	
	@Autowired
	UsersRepository UR;
	
	@Autowired
	JWTManager JM;
	
	public String addUser(Users U)
	{
		if(UR.validateEmail(U.getEmail()) > 0)
			return "Email Already Exist";
		
		UR.save(U);
		return "User added successfully";
	}
	
	public String login(String email, String password)
	{
		if(UR.validateCredentials(email, password) > 0)
		{
			String token = JM.generateToken(email);
			return "200::" + token ;
		}
		return "401::Invalid Credentials";
	}
	
	public String getFullname(String token) 
	{
		String email = JM.validateToken(token);
		if (email.compareTo("401") == 0)
			return "401::Token Expired";
			Users U = UR.findById(email).get();
		return U.getFullname();					
	 }
	}
