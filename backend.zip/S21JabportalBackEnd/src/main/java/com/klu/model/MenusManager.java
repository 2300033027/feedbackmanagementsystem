package com.klu.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.GsonBuilder;
import com.klu.repository.MenusRepository;
import com.klu.repository.UsersRepository;

@Service
public class MenusManager {

	
	@Autowired
	UsersRepository UR;
	
	@Autowired
	JWTManager JM;
	
	@Autowired
	MenusRepository MR;
	  public String getMenusByRole(String token)
	  {
	    String email = JM.validateToken(token);
	    if(email.compareTo("401") == 0)
	      return "401::Token Expired";
	    
	    Users U = UR.findById(email).get();
	    List<Menus> menulist = MR.findByRole(U.getRole());
	    return new GsonBuilder().create().toJson(menulist).toString();
	  }
}